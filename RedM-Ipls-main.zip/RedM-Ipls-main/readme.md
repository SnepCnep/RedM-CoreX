# RedM Ipls
- Fix for the missing ipls in RedM and fixes.


## Script owner
- https://github.com/Rexshack-RedM/redm-ipls
