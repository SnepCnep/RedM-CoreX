-- [[ CRX Framework Core ]] --
CRX = {}

exports('getSharedObject', function()
    return CRX
end)

