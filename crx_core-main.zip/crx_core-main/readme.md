# CRX - Corex Framework ( REDM )

## Introduction


## Installation


## Requirements
- [ox_lib](https://github.com/overextended/ox_inventory)
- [ox_mysql](https://github.com/overextended/oxmysql)
- ox_inventory ( our version ) ( SOON )
- ox_target ( our version ) ( SOON )
