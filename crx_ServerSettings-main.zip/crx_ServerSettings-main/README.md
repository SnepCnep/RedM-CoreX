# Redm Server.CFG

A template server.cfg for the framework CRX ( Corex Framework )
